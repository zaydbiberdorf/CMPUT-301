package com.example.lab2;

public class City {
    private String cityName;

    public City(String cityName){
        this.cityName = cityName;
    }

    public String getCityName(){
        return this.cityName;
    }
}
